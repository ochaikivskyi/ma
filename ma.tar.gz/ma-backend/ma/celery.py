import os

from celery import Celery
from celery.schedules import crontab


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ma.settings")

app = Celery("ma")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.conf.broker_url = 'redis://redis:6379/0'
app.conf.result_backend = 'redis://redis:6379/0'
app.autodiscover_tasks()
app.conf.beat_scheduler = 'django_celery_beat.schedulers.DatabaseScheduler'

app.conf.beat_schedule = {
    "check_cognitive_notification": {
        "task": "apps.notifications.tasks.check_cognitive_notification",
        "schedule": crontab(minute="*/60"),
    },
    "check_physical_notification": {
        "task": "apps.notifications.tasks.check_physical_notification",
        "schedule": crontab(minute="*/60"),
    },
    "check_daily_checkin_notification": {
        "task": "apps.notifications.tasks.check_daily_checkin_notification",
        "schedule": crontab(minute="*/60"),
    },
}
