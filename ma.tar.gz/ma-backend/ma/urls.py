from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path, include
from django.views.generic import TemplateView
from rest_framework_simplejwt.views import (
    TokenRefreshView,
    TokenVerifyView,
)
from fcm_django.api.rest_framework import FCMDeviceAuthorizedViewSet
from rest_framework.routers import DefaultRouter
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

from apps.authorization.views import (
    LogoutGenericAPIView,
    CustomTokenObtainPairView,
    FacebookLogin,
    GoogleLogin
)

from apps.accounts.views import (
    EmailVerificationAPIView,
    ChangePasswordView,
    CustomPasswordResetView,
    CustomPasswordResetConfirmView
)

from ma import settings

from ma.settings import DEBUG

schema_view = get_schema_view(
    openapi.Info(
        title="Modern Aging Snippets API",
        default_version='v1',
        description="Test description",
        terms_of_service="https://www.google.com/policies/terms/",
        contact=openapi.Contact(email="contact@snippets.local"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
)

router = DefaultRouter()
router.register('devices', FCMDeviceAuthorizedViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path(
        "api/v1/accounts/",
        include(
            ("apps.accounts.urls", "apps.accounts"),
            namespace="accounts"
        )
    ),
    path(
        'api/v1/auth/change-password/',
        ChangePasswordView.as_view(),
        name='change_password'
    ),
    path(
        'api/v1/auth/password-reset/',
        CustomPasswordResetView.as_view(),
        name='password_reset'
    ),
    path(
        'api/v1/auth/reset-password/confirm/<uidb64>/<token>/',
        CustomPasswordResetConfirmView.as_view(),
        name='password_reset_confirm'
    ),

    path('api/v1/auth/', include('rest_framework.urls')),

    path('api/v1/rest-auth/facebook/', FacebookLogin.as_view(), name='facebook'),
    path('api/v1/rest-auth/google/', GoogleLogin.as_view(), name='google'),

    path(
        "api/v1/auth/signin/",
        CustomTokenObtainPairView.as_view(),
        name="token_obtain_pair"
    ),
    path(
        "api/v1/auth/signin/token/refresh/",
        TokenRefreshView.as_view(),
        name="token_refresh"
    ),
    path(
        "api/v1/auth/signin/token/verify/",
        TokenVerifyView.as_view(),
        name="token_verify"
    ),
    path(
        "api/v1/accounts/email-verification/",
        EmailVerificationAPIView.as_view(),
        name="email_verification"
    ),
    path(
        "api/v1/auth/signout/",
        LogoutGenericAPIView.as_view(),
        name="sign_out"
    ),
    path(
        "api/v1/widgets/",
        include("apps.widgets.urls"),
        name='widgets'
    ),
    path(
        "api/v1/physical-tests/",
        include("apps.physical_test.urls"),
        name='physical-test'
    ),
    path(
        "api/v1/voice-tests/",
        include(
            ("apps.voice_test.urls", "apps.voice_test"),
            namespace='voice-test'
        )
    ),
    path(
        "api/v1/health-report-card/",
        include(
            ("apps.health_report.urls", "apps.health_report"),
            namespace='health-report-card'
        )
    ),
    path(
        'swagger/',
        schema_view.with_ui('swagger', cache_timeout=0),
        name='schema-swagger-ui'
    ),
    path(
        'redoc/',
        schema_view.with_ui('redoc', cache_timeout=0),
        name='schema-redoc'
    ),
    path(
        "api/v1/notifications/",
        include("apps.notifications.urls"),
        name='notifications'
    ),
    # static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
]

if DEBUG:
    urlpatterns += [
                       path('__debug__/', include('debug_toolbar.urls')),
                   ] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    urlpatterns += staticfiles_urlpatterns()
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
