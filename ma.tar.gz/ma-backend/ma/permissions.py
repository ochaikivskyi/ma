from rest_framework import permissions


class UserPermission(permissions.BasePermission):
    """
    Global permission checker
    """

    def has_permission(self, request, view):
        
        if request.user.is_superuser:
            return True
        
        permission_code = self.get_codename(
            view.action, view.get_queryset().model._meta.model_name)
        if request.user.has_perm(permission_code):
            return True
        
        return False

    def get_codename(self, method, model):
        type = ""
        get_list = ["list", "retrieve"]
        update_list = ["update", "partial_update"]
        
        if method in get_list or  len( list( filter(lambda elem: method in elem, get_list) ) ):
            type = "view"
        
        if method == "create" or "create" in method:
            type = "add"
            
        if method in update_list or len(list(filter(lambda elem: method in elem, update_list))):
            type = "change"
            
        if method == "destroy" or "destroy" in method:
            type = "delete"
        
        return type + "_" + model
