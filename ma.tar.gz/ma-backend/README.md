# Api

## Private api

For start project you can use following commands:

```sh
$ make all # setup and start all
```
```sh
$ make setup # setup environment and install requirements for project
```
```sh
$ make db # apply migrations
```
```sh
$ make run # run server and start apps
```
