#!/bin/bash

python3 manage.py makemigrations
python3 manage.py migrate
source venv/bin/activate
#pip3 install -r requirements.txt
docker-compose up --build
docker-compose down
docker-compose up -d
docker-compose ps
