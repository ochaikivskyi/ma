# How to contribute
This document captures the way contributions are made to this repository

## **Did you write a patch that fixes a bug or adds a feature ?**

* Open a new GitHub pull request with the patch.

* Ensure the PR description clearly describes the problem and solution.
  Make sure the title of the PR starts with:
    - `feat: ` a major feature,
    - `refactor: ` a patch,
    - `fix: ` minor one,
    - `doc: ` documentation related.

  Include the relevant Jira issue number if applicable.
  
  Make sure commit message contains the path to the actual app

* Once submitted, make sure to add reviewers.
