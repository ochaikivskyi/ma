import calendar

import random
from datetime import date, datetime, timedelta

from django.db.models import Avg, Max, Min
from django.utils import timezone
from typing import Union, Dict, List

from geopy.geocoders import Nominatim

from apps.accounts.models import User
from apps.accounts.models import UserProfile
from apps.physical_test.models import SLUMS, LSNS, HADS, FiveMinuteWalk, SitToStand
from apps.voice_test.models import ReadPassageAloud
from apps.widgets.models import DailyCheckin

US_STATE_ABBREVIATIONS = {
    "Alabama": "AL",
    "Alaska": "AK",
    "Arizona": "AZ",
    "Arkansas": "AR",
    "California": "CA",
    "Colorado": "CO",
    "Connecticut": "CT",
    "Delaware": "DE",
    "Florida": "FL",
    "Georgia": "GA",
    "Hawaii": "HI",
    "Idaho": "ID",
    "Illinois": "IL",
    "Indiana": "IN",
    "Iowa": "IA",
    "Kansas": "KS",
    "Kentucky": "KY",
    "Louisiana": "LA",
    "Maine": "ME",
    "Maryland": "MD",
    "Massachusetts": "MA",
    "Michigan": "MI",
    "Minnesota": "MN",
    "Mississippi": "MS",
    "Missouri": "MO",
    "Montana": "MT",
    "Nebraska": "NE",
    "Nevada": "NV",
    "New Hampshire": "NH",
    "New Jersey": "NJ",
    "New Mexico": "NM",
    "New York": "NY",
    "North Carolina": "NC",
    "North Dakota": "ND",
    "Northern Mariana Islands": "MP",
    "Ohio": "OH",
    "Oklahoma": "OK",
    "Oregon": "OR",
    "Palau": "PW",
    "Pennsylvania": "PA",
    "Rhode Island": "RI",
    "Puerto Rico": "PR",
    "South Carolina": "SC",
    "South Dakota": "SD",
    "Tennessee": "TN",
    "Texas": "TX",
    "Utah": "UT",
    "Vermont": "VT",
    "Virginia": "VA",
    "Washington": "WA",
    "Washington, DC": "DC",
    "West Virginia": "WV",
    "Wisconsin": "WI",
    "Wyoming": "WY",
    "Virgin Islands": "VI",
}

LIST_OF_ANIMALS = [
    'Prawn', 'Wildebeest', 'Monkey', 'Swallow', 'Bee', 'Koi', 'Roundworm', 'Prairie', 'Butterfly',
    'Shrimp', 'Dormouse', 'Wildcat', 'Lion', 'Goose', 'Puffin', 'Cobra', 'Hummingbird', 'Jay',
    'Dinosaur', 'Hermit', 'Junglefowl', 'Toad', 'Silkmoth', 'Spider', 'Pike', 'Mule', 'Weasel', 'Turkey', 'Robin',
    'Flyingfish', 'Parrotfish', 'Warbler', 'Vole', 'Tuna', 'Mouse', 'Seahorse', 'Buffalo', 'Steelhead', 'Chameleon',
    'Gopher', 'Leech', 'Gayal', 'Tern', 'Zebra', 'Duck', 'Iguana', 'Eel', 'Hippopotamus', 'Varieties', 'Jackal',
    'Jaguar', 'Termite', 'Flea', 'Elephant', 'Alpaca', 'Loon', 'Snipe', 'Wallaby', 'Porcupine', 'Canary', 'Lynx',
    'Hammerhead', 'Spoonbill', 'Marten', 'Scallop', 'Magpie', 'Mosquito', 'Lungfish', 'Takin', 'Hoverfly', 'Tick',
    'Buzzard', 'Heron', 'Arabian', 'Walrus', 'Thrush', 'Blackbird', 'Damselfly', 'Mollusk', 'Mandrill', 'Mockingbird',
    'Goat', 'Cicada', 'Dragonfly', 'Snail', 'Trapdoor', 'Smelt', 'Wolf', 'Frog', 'Chinchilla', 'Salmon', 'Galliform',
    'Kiwi', 'Perch', 'Tarsier', 'Mastodon', 'Fox', 'Donkey', 'Mantis', 'Shrew', 'Fighting', 'Breeds', 'Harrier',
    'Sheep', 'Quokka', 'Pony', 'Rattlesnake', 'Cardinal', 'Boar', 'Chicken', 'Guppy', 'Bat', 'Shark', 'Guan', 'Fruit',
    'Grizzly', 'Sperm', 'Peacock', 'Anaconda', 'Silverfish', 'Eagle', 'Capybara', 'Bird', 'Pinniped', 'Pilot', 'Cougar',
    'Tarantula', 'Krill', 'Bali', 'Echidna', 'Clam', 'Orangutan', 'Dog', 'Starfish', 'Flamingo', 'Manatee', 'Planarian',
    'Peafowl', 'Guinea', 'Bonobo', 'Goldfish', 'Impala', 'Pointer', 'Lizard', 'Pig', 'Pigeon', 'Black', 'Centipede',
    'Skink', 'Falcon', 'Cow', 'Kingfisher', 'Marsupial', 'Locust', 'Limpet', 'Asp', 'Gila', 'Bear', 'Trout', 'Whale',
    'Rat', 'Crab', 'Cephalopod', 'Orca', 'Peregrine', 'Fancy', 'Red', 'Newt', 'Hamster', 'Canidae', 'Baboon', 'Wasp',
    'Catshark', 'Mongoose', 'Grasshopper', 'Raccoon', 'Bobcat', 'Alligator', 'Gecko', 'Salamander', 'Herring', 'Dove',
    'Marlin', 'Beaver', 'Felidae', 'Boa', 'Constrictor', 'Swordtail', 'Polar', 'Landfowl', 'Marmoset', 'List', 'Blue',
    'Arrow', 'Chickadee', 'Ray', 'Stoat', 'Puma', 'Meerkat', 'Lark', 'Worm', 'Primate', 'Sparrow', 'Marmot', 'Snake',
    'Wildfowl', 'Wren', 'Gorilla', 'Halibut', 'Land', 'Devil', 'Mole', 'Sea', 'Stork', 'Otter', 'Crayfish', 'New',
    'Ostrich', 'Hedgehog', 'Slug', 'Parrot', 'Horse', 'Barracuda', 'Gull', 'Reptile', 'Beaked', 'Bug', 'Komodo', 'Mite',
    'Moose', 'Partridge', 'Chipmunk', 'Tortoise', 'Tasmanian', 'Woodpecker', 'Donkey', 'Raven', 'Guanaco', 'Giraffe',
    'Stingray', 'Fish', 'Cattle', 'Macaw', 'Strains', 'Yak', 'Porpoise', 'Dolphin', 'Ocelot', 'Water', 'Skunk',
    'Firefly', 'Giant', 'Chimpanzee', 'Leopon', 'Mackerel', 'Rhinoceros', 'Buffalo,', 'Saber-toothed', 'Urial',
    'Whitefish', 'Cheetah', 'Emu', 'Lemur', 'Guineafowl', 'Minnow', 'Anteater', 'Camel', 'Deer', 'Coyote', 'Gerbil',
    'Aardvark', 'Gibbon', 'Quelea', 'Earwig', 'Booby', 'Beetle', 'Leopard', 'Laboratory', 'Ground', 'Ferret',
    'Bobolink', 'Irukandji', 'Narwhal', 'Ox', 'Ladybug', 'Llama', 'Koala', 'Crow', 'Opossum', 'Albatross', 'Ptarmigan',
    'Swan', 'Silkworm', 'Meadowlark', 'Viper', 'Ermine', 'Jellyfish', 'Panther', 'Muskox', 'Penguin', 'Cockroach',
    'Hare', 'Squid', 'Tiglon', 'Wolverine', 'Octopus', 'Grouse', 'Rabbit', 'Hookworm', 'Antelope', 'Mammal', 'Toucan',
    'Earthworm', 'Panthera', 'Aphid', 'Fly', 'Widow', 'Sawfish', 'Rooster', 'Rainbow', 'Vicuna', 'Clownfish', 'Bison',
    'Amphibian', 'Anglerfish', 'Armadillo', 'Finch', 'Cat', 'Aardwolf', 'Bandicoot', 'Rodent', 'Lemming', 'Sturgeon',
    'Wombat', 'Reindeer', 'Sole', 'Roadrunner', 'Louse', 'Hybrid', 'Angelfish', 'Pheasant', 'Carp', 'Moth', 'Owl',
    'Hyena', 'Bovid', 'Mink', 'Cuckoo', 'Coral', 'Dragon', 'Tapir', 'Kite', 'Lamprey', 'Haddock', 'Glider', 'Condor',
    'Bedbug', 'Caterpillar', 'Lobster', 'Dingo', 'Sailfish', 'Scale', 'Possum', 'Squirrel', 'Swordfish', 'Dung',
    'Hornet', 'Catfish', 'Canid', 'Crawdad', 'Snow', 'Cape', 'Praying', 'Fowl', 'Caribou', 'Sloth', 'Pelican', 'Manta',
    'Antlion', 'Ape', 'Gazelle', 'Mountain', 'Badger', 'Turtle', 'Scorpion', 'Tahr', 'Parakeet', 'Gamefowl', 'Tiger',
    'Hawk', 'Egret', 'Whippet', 'Vulture', 'Piranha', 'Crocodile', 'Dromedary', 'Basilisk', 'Quail', 'Barnacle', 'Seal',
    'Humpback', 'Tyrannosaurus', 'Python', 'Crane', 'Panda', 'Sockeye', 'Cod', 'Cricket', 'Ant', 'Rook', 'Kangaroo',
    'Nightingale', 'Platypus', 'Elk'
]

TESTS = {
    'slums': SLUMS,
    'lsns': LSNS,
    'five_minute_walk': FiveMinuteWalk,
    'hads': HADS,
    'sit_to_stand': SitToStand,
    'read_passage_aloud': ReadPassageAloud
}


def estimate_slums_data(user_id: str, answers: list) -> SLUMS:
    """
    function provides the analysis of answers given by user
    and respectively receiving the mark about his mental health
    based on it
    """

    userprofile = UserProfile.objects.get(user_id=user_id)
    slums = SLUMS()
    slums.total_result = 0
    for answer in answers:
        if answer["type"] == "weekday":
            if answer["value"] == calendar.day_name[date.today().weekday()]:
                slums.day_of_week = 1
                slums.total_result += 1
            else:
                slums.day_of_week = 0

        elif answer["type"] == "year":
            if answer["value"] == date.today().year:
                slums.year = 1
                slums.total_result += 1
            else:
                slums.year = 0

        elif answer["type"] == "state":
            if answer.get("value").get("coordinates"):
                geolocator = Nominatim(user_agent="app")
                location = geolocator.reverse(
                    [answer['value']['coordinates']['lat'], answer['value']['coordinates']['lon']]
                )
                if location.raw["address"]["state"].capitalize() == answer["value"]["user_input"][
                    "state_name"].capitalize():
                    slums.state = 1
                    slums.total_result += 1
                else:
                    slums.state = 0
            else:
                if (
                        answer["value"]["user_input"]["state_name"].capitalize()
                        in US_STATE_ABBREVIATIONS.keys()
                ):
                    slums.state = 1
                    slums.total_result += 1
                else:
                    slums.state = 0

        elif answer["type"] == "spending":
            if answer["value"]["spend"] == 23:
                slums.money_spent = 1
                slums.total_result += 1
            else:
                slums.money_spent = 0

            if answer["value"]["left"] == 67:
                slums.money_left = 2
                slums.total_result += 1
            else:
                slums.money_left = 0

        elif answer['type'] == 'count_animals':
            if len(answer['value']) >= 5:
                for value in answer['value']:
                    if value in LIST_OF_ANIMALS:
                        continue
                    else:
                        break
                slums.animals = 1
                slums.total_result += 1
            elif len(answer['value']) >= 10:
                for value in answer['value']:
                    if value in LIST_OF_ANIMALS:
                        continue
                    else:
                        break
                slums.animals = 2
                slums.total_result += 2
            elif len(answer['value']) >= 15:
                for value in answer['value']:
                    if value in LIST_OF_ANIMALS:
                        continue
                    else:
                        break
                slums.animals = 3
                slums.total_result += 3
            else:
                slums.animals = 0

        elif answer["type"] == "remember":
            slums.remembered_objects = 0
            for responded_item in answer["value"]["answered"]:
                if responded_item.lower() in answer["value"]["asked"]:
                    slums.remembered_objects += 1
                    slums.total_result += 1
                else:
                    slums.remembered_objects += 0

        elif answer["type"] == "reverse_numbers":
            slums.backwards_numbers = 0
            for backwards_number in answer["value"]["asked"]:

                if (
                        backwards_number in answer["value"]["answered"]
                        and len(str(backwards_number)) > 2
                ):
                    slums.backwards_numbers += 1
                    slums.total_result += 1
                else:
                    slums.backwards_numbers += 0

        elif answer['type'] == 'clock':
            if answer['value']['top_marker'] == '12':
                slums.hour_markers_correct = 2
                slums.total_result += 2
            else:
                slums.hour_markers_correct = 0
            if answer['value']['left_marker'] == '9':
                slums.hour_markers_correct = 2
                slums.total_result += 2
            else:
                slums.hour_markers_correct = 0
            if answer['value']['right_marker'] == '3':
                slums.hour_markers_correct = 2
                slums.total_result += 2
            else:
                slums.hour_markers_correct = 0
            if answer['value']['bottom_marker'] == '6':
                slums.hour_markers_correct = 2
                slums.total_result += 2
            else:
                slums.hour_markers_correct = 0

            if answer['value']['hour_hand_angle'] in range(270, 360):
                slums.time_correct = 2
                slums.total_result += 2
            else:
                slums.time_correct = 0
            if answer['value']['minute_hand_angle'] in range(270, 360):

                slums.time_correct = 2
                slums.total_result += 2
            else:
                slums.time_correct = 0

        elif answer['type'] == 'figures':
            if answer['value']['select_triangle'].lower() == 'triangle':
                slums.is_triangle = 1
                slums.total_result += 1
            else:
                slums.is_triangle = 0

            if answer['value']['select_largest'].lower() == 'square':

                slums.is_triangle = 1
                slums.total_result += 1
            else:
                slums.is_triangle = 0

        elif answer["type"] == "auditioning":
            if answer["value"]["female_name"].lower() == "jill":
                slums.female_name = 2
                slums.total_result += 2
            else:
                slums.female_name = 0

            if answer["value"]["work_she_do"].lower() == "stockbroker":
                slums.work_she_does = 2
                slums.total_result += 2
            else:
                slums.work_she_does = 0

            if answer["value"]["back_to_work"].lower() == "teenagers":
                slums.she_back_to_work = 2
                slums.total_result += 2
            else:
                slums.she_back_to_work = 0

            if answer["value"]["state_live_in"].lower() == "illinois":
                slums.state_she_live_in = 2
                slums.total_result += 2
            else:
                slums.state_she_live_in = 0

    slums.user = user_id
    slums.answers = answers
    if userprofile.education == userprofile.SCHOOL:
        if slums.total_result >= 25:
            slums.diagnosis = slums.NORMAL
        if slums.total_result >= 20:
            slums.diagnosis = slums.MILD_DISORDER
        if slums.total_result < 20:
            slums.diagnosis = slums.DEMENTIA
    else:
        if slums.total_result >= 27:
            slums.diagnosis = slums.NORMAL
        if slums.total_result >= 21:
            slums.diagnosis = slums.MILD_DISORDER
        if slums.total_result <= 20:
            slums.diagnosis = slums.DEMENTIA
    slums.save()
    return slums


class UserDataChecker:
    def __init__(self, user: User):
        self.user = user

    def check_sign_up(self) -> bool:
        if User.objects.get(id=self.user.id):
            return True
        else:
            return False

    def check_userprofile_is_fulfiled(self) -> Union[bool, str]:
        try:
            userprofile = UserProfile.objects.get(user=self.user)
            if (
                    not userprofile.date_of_birth
                    or not userprofile.gender
                    or not userprofile.is_smoker
                    or not userprofile.is_drinker
                    or not userprofile.weight
                    or not userprofile.height
            ):
                return False
            else:
                return True
        except UserProfile.DoesNotExist:
            return "UserProfile not found"

    def check_test_is_fulfilled(self, test):
        test = test.objects.filter(user=self.user)
        if test:
            return True
        else:
            return False

    def get_user_profile_data(self) -> Dict:

        return {
            "user_sign_up": self.check_sign_up(),
            "userprofile_info": self.check_userprofile_is_fulfiled(),
            "slums": self.check_test_is_fulfilled(SLUMS),
            "hads": self.check_test_is_fulfilled(HADS),
            "lsns": self.check_test_is_fulfilled(LSNS),
            "sit_to_stand": self.check_test_is_fulfilled(SitToStand),
            "5_minute_walk": self.check_test_is_fulfilled(FiveMinuteWalk),
            "read_passage_aloud": self.check_test_is_fulfilled(ReadPassageAloud),
        }


def get_hads_total_score(hads_points: List) -> int:
    return sum(hads_points)


def get_hads_relatives_total_score(hads_data: Dict) -> int:
    relatives_data = dict()
    relatives_data["num_relatives_per_month"] = hads_data.get("num_relatives_per_month")
    relatives_data["relatives_contact_periodicity"] = hads_data.get(
        "relatives_contact_periodicity"
    )
    relatives_data["num_relatives_private_topics"] = hads_data.get(
        "num_relatives_private_topics"
    )
    relatives_data["num_relatives_call_for_help"] = hads_data.get(
        "num_relatives_call_for_help"
    )
    relatives_data[
        "request_for_your_advice_from_relatives_periodicity"
    ] = hads_data.get("request_for_your_advice_from_relatives_periodicity")
    relatives_data[
        "request_to_ask_for_advice_from_relatives_periodicity"
    ] = hads_data.get("request_to_ask_for_advice_from_relatives_periodicity")
    return sum(relatives_data.values())


def get_hads_friends_total_score(hads_data: Dict) -> int:
    friends_data = dict()
    friends_data["num_friends_per_month"] = hads_data.get("num_friends_per_month")
    friends_data["friends_contact_periodicity"] = hads_data.get(
        "friends_contact_periodicity"
    )
    friends_data["num_friends_private_topics"] = hads_data.get(
        "num_friends_private_topics"
    )
    friends_data["num_friends_call_for_help"] = hads_data.get(
        "num_friends_call_for_help"
    )
    friends_data["request_for_your_advice_from_friends_periodicity"] = hads_data.get(
        "request_for_your_advice_from_friends_periodicity"
    )
    friends_data["request_to_ask_for_advice_from_friends_periodicity"] = hads_data.get(
        "request_to_ask_for_advice_from_friends_periodicity"
    )
    return sum(friends_data.values())


class AvailabilityChecker:
    def __init__(self, user: User):
        self.user = user

    def check_daily_checkin(self) -> str:
        try:
            daily_checkin = DailyCheckin.objects.filter(user=self.user).last()
            return (daily_checkin.created_at.replace(tzinfo=None) + timedelta(days=1)).isoformat()
        except AttributeError:
            return (datetime.today()).isoformat()

    def check_available_in(self, test, assessment_days: int) -> str:
        try:
            test = test.objects.filter(user=self.user).last()
            return (
                    test.created_at.replace(tzinfo=None) + timedelta(days=assessment_days)
            ).isoformat()
        except AttributeError:
            return (datetime.today()).isoformat()

    def check_current_streak(self) -> int:
        total_streak = 0
        current_streak = 0
        compare_date = datetime.now(tz=timezone.utc)
        # Using list() here pulls all the entries from the DB at once
        # Gets all entry dates for this dailyCheckin and whose dates are <= today
        entry_dates = list(
            DailyCheckin.objects.filter(
                user=self.user, created_at__lte=datetime.now(tz=timezone.utc)
            ).order_by("-created_at")
        )
        for day in entry_dates:
            # Get the difference btw the dates
            delta = compare_date - day.created_at
            if delta.days == 1:  # Keep the streak going!
                current_streak += 1
            elif delta.days == 0:  # Don't bother increasing the day if there's multiple ones on the same day
                current_streak = 1
            elif delta.days > 1:
                break
            else:
                current_streak = 1

            compare_date = day.created_at

        if current_streak > total_streak:
            total_streak = current_streak

        return total_streak

    def check_homepage(self) -> dict:
        return {
            "daily_checkin": self.check_daily_checkin(),
            "current_streak": self.check_current_streak(),
            "available_in": {
                "slums": self.check_available_in(SLUMS, 90),
                "hads": self.check_available_in(HADS, 90),
                "lsns": self.check_available_in(LSNS, 90),
                "read_passage_aloud": self.check_available_in(ReadPassageAloud, 90),
                "five_minute_walk": self.check_available_in(FiveMinuteWalk, 1),
                "sit_to_stand": self.check_available_in(SitToStand, 1),
            },
        }


class DailyCheckinQuestions:
    physical = {
        "nutrition": {
            "id": 1,
            "question": "How would you rate your nutrition over the past few days?",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "Great!"
                },
                {
                    "id": 2,
                    "content": "Pretty good"
                },
                {
                    "id": 3,
                    "content": "Okay, but needs improvement"
                },
                {
                    "id": 4,
                    "content": "Very poor"
                }
            ]
        },
        "plants": {
            "id": 2,
            "question": "How many servings of fruits and vegetables did you eat yesterday?",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "None"
                },
                {
                    "id": 2,
                    "content": "1 - 2 servings"
                },
                {
                    "id": 3,
                    "content": "3 - 4 servings"
                },
                {
                    "id": 4,
                    "content": "5 or more servings"
                }
            ]
        },
        "sleep": {
            "id": 3,
            "question": "How long has it taken you to fall asleep the last few nights?",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "0 - 5 minutes"
                },
                {
                    "id": 2,
                    "content": "5 - 15 minutes"
                },
                {
                    "id": 3,
                    "content": "15 - 30 minutes"
                },
                {
                    "id": 4,
                    "content": "More than 30 min"
                }
            ]
        },
        "sleep_duration": {
            "id": 4,
            "question": "How many hours of sleep did you get last night?",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "4 or less"
                },
                {
                    "id": 2,
                    "content": "4 - 6"
                },
                {
                    "id": 3,
                    "content": "6 - 8"
                },
                {
                    "id": 4,
                    "content": "8 - 10"
                },
                {
                    "id": 5,
                    "content": "More than 10"
                }
            ]
        },
        "water": {
            "id": 5,
            "question": "How much water did you drink yesterday?",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "I do not drink any water"
                },
                {
                    "id": 2,
                    "content": "1 - 3 glasses"
                },
                {
                    "id": 3,
                    "content": "3 - 5 glasses"
                },
                {
                    "id": 4,
                    "content": "5 or more glasses"
                }
            ]
        },
        "pain": {
            "id": 6,
            "question": "Are you experiencing any pain or discomfort?",
            "answerType": "singleChoiceWithInput",
            "expandable_option_id": 1,
            "options": [
                {
                    "id": 1,
                    "content": "Yes"
                },
                {
                    "id": 2,
                    "content": "No"
                }
            ]
        },
        "exercise": {
            "id": 7,
            "question": "How much exercise did you get within the past 3 days?",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "None"
                },
                {
                    "id": 2,
                    "content": "< 30 minutes"
                },
                {
                    "id": 3,
                    "content": "30 minutes to 1 hour"
                },
                {
                    "id": 4,
                    "content": "more than 1 hour"
                }
            ]
        },
    }
    cognitive = {
        "day_of_week": {
            "id": 1,
            "question": "What day of the week is it?",
            "answerType": "dayOfWeek",
            "options": []
        },
        "math": {
            "id": 2,
            "question": 'You have $50 and you go to the store and buy a small '
                        'screwdriver for $7 and a tape measure for $9',
            "answerType": "mathCalculation",
            "options": []
        },
        "location": {
            "id": 3,
            "question": 'What city are in right now?',
            "answerType": "city",
            "options": []
        },
        "animal": {
            "id": 4,
            "question": 'Show each animal in turn and ask them to name each one',
            "answerType": "nameObject",
            "options": [
                {
                    "id": 1,
                    "name": "Camel",
                    "imageUrl": 'http://54.226.24.171:8000/media/images/Camel.png'
                    # Image.open(glob.glob('apps/utils/images/Camel.png')[0])
                },
                {
                    "id": 2,
                    "name": "Giraffe",
                    "imageUrl": 'http://54.226.24.171:8000/media/images/Giraffe.png'
                    # Image.open(glob.glob('apps/utils/images/Giraffe.png')[0])
                },
                {
                    "id": 3,
                    "name": "Hippo",
                    "imageUrl": 'http://54.226.24.171:8000/media/images/hippo.png'
                    # Image.open(glob.glob('apps/utils/images/hippo.png')[0])
                },
            ]
        },
        "animal_2": {
            "id": 5,
            "question": 'Show each animal in turn and ask them to name each one',
            "answerType": "nameObject",
            "options": [
                {
                    "id": 4,
                    "name": "Lion",
                    "imageUrl": 'http://54.226.24.171:8000/media/images/Lion.png'
                    # Image.open(glob.glob('apps/utils/images/Lion.png')[0])
                },
                {
                    "id": 5,
                    "name": "Penguin",
                    "imageUrl": 'http://54.226.24.171:8000/media/images/Penguin.png'
                    # Image.open(glob.glob('apps/utils/images/Penguin.png')[0])
                },
                {
                    "id": 6,
                    "name": "Rhinoceros",
                    "imageUrl": 'http://54.226.24.171:8000/media/images/Rhinoceros.png'
                    # Image.open(glob.glob('apps/utils/images/Rhinoceros.png')[0])
                },
            ]
        },
        "star": {
            "id": 6,
            "question": 'Please place an X inside the star',
            "answerType": "selectFigure",
            "options": [{
                "id": 7,
                "name": "Star",
                "imageUrl": 'http://54.226.24.171:8000/media/images/Star.png'
            }, random.choices(
                [
                    {
                        "id": 8,
                        "name": "Octagon",
                        "imageUrl": 'http://54.226.24.171:8000/media/images/octagon.png'
                    },
                    {
                        "id": 9,
                        "name": "Rectangle",
                        "imageUrl": 'http://54.226.24.171:8000/media/images/rectangle.png'
                    },
                ]
            ), random.choices(
                [
                    {
                        "id": 10,
                        "name": "Square",
                        "imageUrl": 'http://54.226.24.171:8000/media/images/square.png'
                    },
                    {
                        "id": 11,
                        "name": "Triangle",
                        "imageUrl": 'http://54.226.24.171:8000/media/images/triangle.png'
                    }
                ]
            ),
            ]
        },
        "tips": {
            "id": 7,
            "question": 'You go out to dinner and spend $60 for entrees and drinks. '
                        'Your waiter brings the bill and you want to tip 20%. What will your total bill be?',
            "answerType": "mathPercentage",
            "options": []
        }
    }
    emotional = {
        "something_good": {
            "id": 1,
            "question": "What is something good that happened yesterday?",
            "answerType": "textInput",
            "options": []
        },
        "looking_forward": {
            "id": 2,
            "question": "What’s something you are looking forward to today?",
            "answerType": "textInput",
            "options": []
        },
        "worried_about": {
            "id": 3,
            "question": "Are you worried about anything right now?",
            "answerType": "textInput",
            "options": []
        },
        "friend": {
            "id": 4,
            "question": "Have you spoken to a friend recently?",
            "answerType": "textInput",
            "options": []
        },
        "feel_today": {
            "id": 5,
            "question": "Have you spoken to a friend recently?",
            "answerType": "feeling",
            "options": [
                {
                    "id": 1,
                    "content": "Great!"
                },
                {
                    "id": 2,
                    "content": "Pretty good"
                },
                {
                    "id": 3,
                    "content": "Okay, but needs improvement"
                },
                {
                    "id": 4,
                    "content": "Bad"
                },
                {
                    "id": 5,
                    "content": "Very bad"
                }
            ]
        },
        "cultivate_effort": {
            "id": 6,
            "question": "I believe that my basic qualities are things I can cultivate through my efforts",
            "answerType": "singleChoice",
            "options": [
                {
                    "id": 1,
                    "content": "True"
                },
                {
                    "id": 2,
                    "content": "False"
                }
            ]
        },
    }

    def __init__(self, user: User):
        self.user = user
        self.weekly_objects = list(
            DailyCheckin.objects.filter(
                user=user, created_at__gte=datetime.now() - timedelta(days=6)
            )
        )

    def get_daily_checkin_questions(self):
        return {
            "physical": self.get_physical_question(),
            "cognitive": self.get_cognitive_question(),
            "emotional": self.get_emotional_question(),
        }

    def get_physical_question(self):
        daily_checkin = [
            item for item in self.physical if item not in [
                physical.physical_question_id for physical in self.weekly_objects
            ]
        ]
        return self.physical.get(random.choice(daily_checkin))

    def get_cognitive_question(self):
        daily_checkin = [
            item for item in self.cognitive if item not in [
                physical.cognitive_question_id for physical in self.weekly_objects
            ]
        ]
        return self.cognitive.get(random.choice(daily_checkin))

    def get_emotional_question(self):
        daily_checkin = [
            item for item in self.emotional if item not in [
                physical.emotional_question_id for physical in self.weekly_objects
            ]
        ]
        return self.emotional[random.choice(daily_checkin)]


class PerformanceAssessment:

    def __init__(self, user: User, test_type, test_value_to_calculate: str):
        self.user = user
        self.test_queryset = test_type.objects.filter(user=user)
        self.test_value_to_calculate = test_value_to_calculate
        self.attribute_test_value_to_calculate = getattr(test_type, test_value_to_calculate)

    def get_performance_assessment_data(self):
        return {
            # "last_result": getattr(self.test_queryset.last(), self.test_value_to_calculate),
            # "average_result": self.test_queryset.aggregate(Avg(self.test_value_to_calculate)),
            # "graph_data": [
            #     [
            #         [
            #             str(value.created_at.isoformat()), getattr(value, self.test_value_to_calculate)
            #         ] for value in self.test_queryset
            #     ]
            # ],
            # "max_value": list(self.test_queryset.aggregate(Max(self.test_value_to_calculate)).values())[0],
            # "min_value": list(self.test_queryset.aggregate(Min(self.test_value_to_calculate)).values())[0],
            # "comparison_with_previous": {
            #     "percentage_difference": (getattr(
            #         self.test_queryset.order_by('-created_at')[:2][0], self.test_value_to_calculate
            #     ) * 100) / getattr(
            #         self.test_queryset.order_by('-created_at')[:2][1], self.test_value_to_calculate
            #     ) - 100,
            #     "value_difference": [
            #         getattr(
            #             self.test_queryset.order_by('-created_at')[:2][0], self.test_value_to_calculate
            #         ),
            #         getattr(
            #             self.test_queryset.order_by('-created_at')[:2][1], self.test_value_to_calculate
            #         )
            #     ],
            #     "date_difference": [
            #         str(self.test_queryset.order_by('-created_at')[:2][0].created_at.isoformat()),
            #         str(self.test_queryset.order_by('-created_at')[:2][1].created_at.isoformat())
            #     ]
            # },
            "journal": [
                {
                    "x": value.created_at.isoformat(),
                    "y": float(getattr(value, self.test_value_to_calculate))
                } for value in self.test_queryset
            ]
        }
