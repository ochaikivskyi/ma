import jsonfield
from django.db import models

from apps.accounts.models import User
from apps.utils.models import TimeStamp


class LSNS(TimeStamp):
    user = models.ForeignKey(User, related_name="lsns", on_delete=models.CASCADE)

    num_relatives_per_month = models.PositiveSmallIntegerField(blank=True, null=True)
    relatives_contact_periodicity = models.PositiveSmallIntegerField(blank=True, null=True)
    num_relatives_private_topics = models.PositiveSmallIntegerField(blank=True, null=True)
    num_relatives_call_for_help = models.PositiveSmallIntegerField(blank=True, null=True)
    request_for_your_advice_from_relatives_periodicity = models.PositiveSmallIntegerField(blank=True, null=True)
    request_to_ask_for_advice_from_relatives_periodicity = models.PositiveSmallIntegerField(blank=True, null=True)

    num_friends_per_month = models.PositiveSmallIntegerField(blank=True, null=True)
    friends_contact_periodicity = models.PositiveSmallIntegerField(blank=True, null=True)
    num_friends_private_topics = models.PositiveSmallIntegerField(blank=True, null=True)
    num_friends_call_for_help = models.PositiveSmallIntegerField(blank=True, null=True)
    request_for_your_advice_from_friends_periodicity = models.PositiveSmallIntegerField(blank=True, null=True)
    request_to_ask_for_advice_from_friends_periodicity = models.PositiveSmallIntegerField(blank=True, null=True)

    relatives_total_score = models.PositiveSmallIntegerField(blank=True, null=True)
    friends_total_score = models.PositiveSmallIntegerField(blank=True, null=True)
    total_score = models.PositiveSmallIntegerField(blank=True, null=True)


class SitToStand(TimeStamp):
    user = models.ForeignKey(User, related_name="sit_to_stand", on_delete=models.CASCADE)
    sits_quantity = models.PositiveSmallIntegerField(blank=True, null=True, default=0)


class HADS(TimeStamp):
    user = models.ForeignKey(User, related_name="hads", on_delete=models.CASCADE)
    wound_up = models.PositiveSmallIntegerField(blank=True, null=True)
    still_enjoy_things = models.PositiveSmallIntegerField(blank=True, null=True)
    something_awful_to_happen = models.PositiveSmallIntegerField(blank=True, null=True)
    see_funny_side_of_things = models.PositiveSmallIntegerField(blank=True, null=True)
    worrying_thoughts_in_mind = models.PositiveSmallIntegerField(blank=True, null=True)
    feeling_cheerful = models.PositiveSmallIntegerField(blank=True, null=True)
    ease_and_relax = models.PositiveSmallIntegerField(blank=True, null=True)
    feel_slowed_down = models.PositiveSmallIntegerField(blank=True, null=True)
    feeling_butterflies_in_stomach = models.PositiveSmallIntegerField(blank=True, null=True)
    interest_in_appearance = models.PositiveSmallIntegerField(blank=True, null=True)
    feeling_restless = models.PositiveSmallIntegerField(blank=True, null=True)
    enjoyment_to_things = models.PositiveSmallIntegerField(blank=True, null=True)
    feeling_of_panic = models.PositiveSmallIntegerField(blank=True, null=True)
    enjoy_radio_book_tv = models.PositiveSmallIntegerField(blank=True, null=True)

    total_score = models.PositiveSmallIntegerField(blank=True, null=True)


class SLUMS(TimeStamp):

    NORMAL = 1
    MILD_DISORDER = 2
    DEMENTIA = 3

    DIAGNOSIS = [
        (NORMAL, 'Normal'),
        (MILD_DISORDER, 'Mild Neurocognitive Disorder'),
        (DEMENTIA, 'Dementia')
    ]

    user = models.ForeignKey(User, related_name="slums", on_delete=models.CASCADE)

    day_of_week = models.PositiveSmallIntegerField(blank=True, null=True)
    year = models.PositiveSmallIntegerField(blank=True, null=True)
    state = models.PositiveSmallIntegerField(blank=True, null=True)
    money_spent = models.PositiveSmallIntegerField(blank=True, null=True)
    money_left = models.PositiveSmallIntegerField(blank=True, null=True)
    animals = models.PositiveSmallIntegerField(blank=True, null=True)
    remembered_objects = models.PositiveSmallIntegerField(blank=True, null=True)
    backwards_numbers = models.PositiveSmallIntegerField(blank=True, null=True)
    hour_markers_correct = models.PositiveSmallIntegerField(blank=True, null=True)
    time_correct = models.PositiveSmallIntegerField(blank=True, null=True)
    is_triangle = models.PositiveSmallIntegerField(blank=True, null=True)
    is_largest = models.PositiveSmallIntegerField(blank=True, null=True)
    female_name = models.PositiveSmallIntegerField(blank=True, null=True)
    she_back_to_work = models.PositiveSmallIntegerField(blank=True, null=True)
    work_she_does = models.PositiveSmallIntegerField(blank=True, null=True)
    state_she_live_in = models.PositiveSmallIntegerField(blank=True, null=True)

    answers = models.TextField(blank=True, null=True)
    diagnosis = models.IntegerField(choices=DIAGNOSIS, null=True, blank=True)

    total_result = models.PositiveSmallIntegerField(blank=True, null=True)


class FiveMinuteWalk(TimeStamp):
    KM = 'km'
    MI = 'mi'

    DISTANCE_TYPE = [
        (KM, 'km'),
        (MI, 'mi'),
    ]

    user = models.ForeignKey(User, related_name="five_minute_walk", on_delete=models.CASCADE)
    distance = models.FloatField(blank=True, null=True)
    distance_type = models.CharField(
        max_length=2,
        choices=DISTANCE_TYPE,
        blank=True,
        null=True,
        default=KM
    )
