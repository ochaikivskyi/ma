from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.physical_test.views import (
    SLUMSViewSet,
    HADSViewSet,
    SitToStandViewSet,
    LSNSViewSet,
    FiveMinuteWalkViewSet,
    SLUMSStateSearchAPIView,
    SLUMSAnimalSearchAPIView,
    PerformanceAssessmentResultView
)

router = DefaultRouter()
router.register("slums", SLUMSViewSet)
router.register("hads", HADSViewSet)
router.register("sit-to-stand", SitToStandViewSet)
router.register("lsns", LSNSViewSet)
router.register("five-minute-walk", FiveMinuteWalkViewSet)

urlpatterns = [
                  path(
                      "slums-state-search/",
                      SLUMSStateSearchAPIView.as_view(),
                      name="slums-state-search"
                  ),
                  path(
                      "slums-animal-search/",
                      SLUMSAnimalSearchAPIView.as_view(),
                      name="slums-animal-search"
                  ),
                  path(
                      "performance-assessment/",
                      PerformanceAssessmentResultView.as_view(),
                      name="performance-assessment"
                  )
              ] + router.urls
