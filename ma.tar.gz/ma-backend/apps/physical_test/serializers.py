from rest_framework import serializers

from apps.physical_test.models import (
    SLUMS,
    HADS,
    SitToStand,
    FiveMinuteWalk,
    LSNS
)


class SLUMSSerializer(serializers.ModelSerializer):
    answers = serializers.ListField()

    class Meta:
        model = SLUMS
        fields = (
            'answers',
        )


class HADSSerializer(serializers.ModelSerializer):

    class Meta:
        model = HADS
        fields = (
            'wound_up',
            'still_enjoy_things',
            'something_awful_to_happen',
            'see_funny_side_of_things',
            'worrying_thoughts_in_mind',
            'feeling_cheerful',
            'ease_and_relax',
            'feel_slowed_down',
            'feeling_butterflies_in_stomach',
            'interest_in_appearance',
            'feeling_restless',
            'enjoyment_to_things',
            'feeling_of_panic',
            'enjoy_radio_book_tv',
            'created_at'
        )


class LSNSSerializer(serializers.ModelSerializer):

    class Meta:
        model = LSNS
        fields = (
            'num_relatives_per_month',
            'relatives_contact_periodicity',
            'num_relatives_private_topics',
            'num_relatives_call_for_help',
            'request_for_your_advice_from_relatives_periodicity',
            'request_to_ask_for_advice_from_relatives_periodicity',
            'num_friends_per_month',
            'friends_contact_periodicity',
            'num_friends_private_topics',
            'num_friends_call_for_help',
            'request_for_your_advice_from_friends_periodicity',
            'request_to_ask_for_advice_from_friends_periodicity',
            'created_at'
        )


class SitToStandSerializer(serializers.ModelSerializer):
    class Meta:
        model = SitToStand
        fields = "__all__"


class FiveMinuteWalkSerializer(serializers.ModelSerializer):
    class Meta:
        model = FiveMinuteWalk
        fields = "__all__"
