from django.contrib import admin

# Register your models here.
from apps.physical_test.models import LSNS, SitToStand, HADS, SLUMS, FiveMinuteWalk

admin.site.register(LSNS)
admin.site.register(SitToStand)
admin.site.register(HADS)
admin.site.register(SLUMS)
admin.site.register(FiveMinuteWalk)
