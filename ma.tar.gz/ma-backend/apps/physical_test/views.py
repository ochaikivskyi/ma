from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from django.db.models import Avg, Max, Min
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet

from apps.accounts.models import User
from apps.physical_test.models import SLUMS, HADS, SitToStand, LSNS, FiveMinuteWalk
from apps.physical_test.serializers import (
    SLUMSSerializer,
    HADSSerializer,
    SitToStandSerializer,
    LSNSSerializer,
    FiveMinuteWalkSerializer
)
from apps.utils.utils import (
    get_hads_total_score,
    get_hads_relatives_total_score,
    get_hads_friends_total_score,
    US_STATE_ABBREVIATIONS,
    estimate_slums_data,
    LIST_OF_ANIMALS,
    PerformanceAssessment,
    TESTS
)


class SLUMSViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = SLUMSSerializer
    queryset = SLUMS.objects.all()

    def create(self, request, *args, **kwargs):
        answers = request.data.pop('answers')
        user = User.objects.get(id=self.request.user.id)
        slums = estimate_slums_data(user, answers)
        return Response(
            data={
                'id': slums.id,
                'user': slums.user_id,
                'diagnosis': slums.diagnosis,
                'total_result': slums.total_result
            },
            status=201
        )

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return SLUMS.objects.all()

        return SLUMS.objects.filter(user=user.id)


class SLUMSStateSearchAPIView(APIView):
    """
    ?search_word=str
    """
    permission_classes = [IsAuthenticated, ]
    search_word = openapi.Parameter(
        'search_word', in_=openapi.IN_QUERY, description='Search word for States',
        type=openapi.TYPE_STRING
    )
    category_response = openapi.Response('[]')

    @swagger_auto_schema(
        manual_parameters=[search_word],
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='List of States',
        operation_description='retrieve States for autocomplete',
    )
    def get(self, *args, **kwargs):
        try:
            search_word = self.request.query_params.get('search_word').capitalize()
            matching = [s for s in US_STATE_ABBREVIATIONS.keys() if search_word in s]
            result = [{'state_code': US_STATE_ABBREVIATIONS[state], 'state_name': state} for state in matching]
            if result:
                return Response(result, status=200)
            else:
                return Response(data=[], status=404)
        except Exception as e:
            return Response(data=[], status=404)


class SLUMSAnimalSearchAPIView(APIView):
    """
    ?search_word=str
    """
    permission_classes = [IsAuthenticated, ]
    search_word = openapi.Parameter(
        'search_word', in_=openapi.IN_QUERY, description='Search word for animals',
        type=openapi.TYPE_STRING
    )
    category_response = openapi.Response('[]')

    @swagger_auto_schema(
        manual_parameters=[search_word],
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='List of animals',
        operation_description='retrieve animals for autocomplete',
    )
    def get(self, *args, **kwargs):
        try:
            search_word = self.request.query_params.get('search_word').capitalize()
            matching = [s for s in LIST_OF_ANIMALS if search_word in s]
            if matching:
                return Response(matching, status=200)
            else:
                return Response(data=[], status=404)
        except Exception as e:
            return Response(data=[], status=404)


class HADSViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated, ]
    serializer_class = HADSSerializer
    queryset = HADS.objects.all()

    def create(self, request, *args, **kwargs):
        total_score = sum(request.data.values())
        request.data['total_score'] = total_score
        lsns = HADS.objects.create(user=self.request.user, **request.data)
        request.data['id'] = lsns.id

        return Response(request.data, status=201)

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return HADS.objects.all()

        return HADS.objects.filter(user=user.id)


class LSNSViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated, ]
    serializer_class = LSNSSerializer
    queryset = LSNS.objects.all()

    def create(self, request, *args, **kwargs):
        request.data['total_score'] = get_hads_total_score(request.data.values())
        request.data['relatives_total_score'] = get_hads_relatives_total_score(request.data)
        request.data['friends_total_score'] = get_hads_friends_total_score(request.data)
        hads = LSNS.objects.create(user=self.request.user, **request.data)
        request.data['id'] = hads.id

        return Response(request.data, status=201)

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return LSNS.objects.all()

        return LSNS.objects.filter(user=user.id)


class SitToStandViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated, )
    serializer_class = SitToStandSerializer
    queryset = SitToStand.objects.all()
    # parser_classes = (FormParser, MultiPartParser)

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return SitToStand.objects.all()

        return SitToStand.objects.filter(user=user.id)


class FiveMinuteWalkViewSet(ModelViewSet):
    permission_classes = (IsAuthenticated, )
    serializer_class = FiveMinuteWalkSerializer
    queryset = FiveMinuteWalk.objects.all()
    # parser_classes = (FormParser, MultiPartParser)

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return FiveMinuteWalk.objects.all()

        return FiveMinuteWalk.objects.filter(user=user.id)


class PerformanceAssessmentResultView(APIView):
    permission_classes = [IsAuthenticated]

    test = openapi.Parameter(
        'test', in_=openapi.IN_QUERY, description='get performance assessment of specific test type. '
                                                  'Key strings to validate test : '
                                                  '["slums", "lsns", "hads", "five_minute_walk", "sit_to_stand"]',
        type=openapi.TYPE_STRING
    )
    attribute = openapi.Parameter(
        'attribute', in_=openapi.IN_QUERY, description='specific attribute to validate in test methods '
                                                       'slums: total_result, lsns: total_score, hads: total_score, '
                                                       'five_minute_walk: distance, sit_to_stand: sits_quantity',
        type=openapi.TYPE_STRING
    )
    category_response = openapi.Response("""{
        # "last_result": float,
        # "average_result": {
        #     "distance__avg": float
        # },
        # "graph_data": [[
        #         DateTime,
        #         float
        #     ]],
        # "max_value": float,
        # "min_value": float,
        # "comparison_with_previous": {
        #     "percentage_difference": float,
        #     "value_difference": [
        #         float,
        #     ],
        #     "date_difference": [
        #         DateTime,
        #     ]
        # },
        "journal": [
            {
                "x": DateTime,
                "y": float
            },
        ]
    }""")

    @swagger_auto_schema(
        manual_parameters=[test, attribute],
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='Performance Assessment',
        operation_description='retrieve animals for autocomplete',
    )
    def get(self, *args, **kwargs):
        try:
            return Response(
                data=PerformanceAssessment(
                    self.request.user,
                    TESTS.get(self.request.query_params.get('test')),
                    self.request.query_params.get('attribute')
                ).get_performance_assessment_data(),
                status=200
            )
        except AttributeError:
            return Response(status=404)
