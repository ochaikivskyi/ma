from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.accounts.views import (
    UserViewSet,
    UserProfileViewSet,
    RegistrationGenericAPIView, CompleteUserProfileAPIView,
)
router = DefaultRouter()
router.register("users", UserViewSet)
router.register("userprofiles", UserProfileViewSet)

urlpatterns = [
                  path(
                      "complete-userprofile/",
                      CompleteUserProfileAPIView.as_view(),
                      name="complete-userprofile"
                  ),
                  path(
                      "signup/",
                      RegistrationGenericAPIView.as_view(),
                      name="signup"
                  ),

              ] + router.urls
