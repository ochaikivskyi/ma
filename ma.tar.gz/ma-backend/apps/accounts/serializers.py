from rest_auth.serializers import PasswordResetSerializer
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

from apps.accounts.models import UserProfile, User
from apps.accounts import validators


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = (
            "id",
            "email",
            "username",
            "password",
            "is_verified",
            "created_at",
            "updated_at"
        )


class UserProfileSerializer(serializers.ModelSerializer):
    date_of_birth = serializers.DateField(validators=[validators.validate_date_of_birth])

    class Meta:
        model = UserProfile
        fields = '__all__'


class ChangePasswordSerializer(serializers.Serializer):
    """
    Serializer for password change endpoint.
    """
    model = User

    old_password = serializers.CharField(required=True)
    new_password_1 = serializers.CharField(required=True)
    new_password_2 = serializers.CharField(required=True)


class CustomPasswordResetSerializer(PasswordResetSerializer):

    def get_email_options(self):
        return {
            'html_email_template_name': 'password_reset_email.html',
        }


class RegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(min_length=8, max_length=68, write_only=True)
    refresh = serializers.SerializerMethodField()
    access = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = (
            "id",
            "username",
            "email",
            "password",
            "refresh",
            "access"
        )

    def get_refresh(self, user):
        tokens = RefreshToken.for_user(user)
        refresh = str(tokens)

        return refresh

    def get_access(self, user):
        tokens = RefreshToken.for_user(user)
        access = str(tokens.access_token)

        return access

    def validate(self, attrs):
        email = attrs.get("email", "")
        username = attrs.get("username", "")

        if username.isalnum:
            return attrs

        raise serializers.ValidationError("Username should contain alphanumeric characters!")

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class EmailVerificationSerializer(serializers.ModelSerializer):
    token = serializers.CharField()

    class Meta:
        model = User
        fields = ('token', )


# class SocialAuthenticationSerializer(serializers.Serializer, ABC):
#     token = serializers.CharField()
