import os

from django.core.exceptions import ValidationError
from datetime import date
from uuid import uuid4


def path_and_rename(instance, filename):
    upload_to = "profile_avatars"
    ext = filename.split('.')[-1]

    if instance.pk:
        filename = "{}.{}".format(instance.pk, ext)
    else:
        filename = "{}.{}".format(uuid4().hex, ext)

    return os.path.join(upload_to, filename)


def validate_date_of_birth(value):
    if value < date(year=1900, month=1, day=1) or value > date.today():
        raise ValidationError("Incorrect date of birth!", params={"value": value})
