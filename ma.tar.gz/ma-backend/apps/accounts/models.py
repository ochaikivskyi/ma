from django.contrib.auth.models import AbstractUser
from django.db import models
from rest_framework_simplejwt.tokens import RefreshToken
from PIL import Image

from apps.accounts.managers import UserManager
from apps.accounts.validators import path_and_rename, validate_date_of_birth


class User(AbstractUser):
    email = models.EmailField(unique=True)
    username = models.CharField(max_length=150, blank=True, null=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_verified = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True, editable=False, null=True)
    updated_at = models.DateTimeField(auto_now=True, editable=False, null=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = UserManager()

    class Meta:
        ordering = ("id", )

    def __str__(self):
        return self.email

    def tokens(self):
        refresh = RefreshToken.for_user(self)
        return {
            "refresh": str(refresh),
            "access": str(refresh.access_token)
        }


class UserProfile(models.Model):

    MALE = 1
    FEMALE = 2
    NOT_CHOSEN = 3

    GENDER = [
        (MALE, 'Male'),
        (FEMALE, 'Female'),
        (NOT_CHOSEN, 'Prefer not to choose'),
    ]

    SCHOOL = 1
    HIGH_SCHOOL = 2
    COLLEGE = 3
    BACHELOR = 4
    MASTER = 5

    EDUCATION = [
        (SCHOOL, 'Did not complete high school'),
        (HIGH_SCHOOL, 'High School or equivalent'),
        (COLLEGE, 'Some college coursework'),
        (BACHELOR, "Bachelor's or Associate degree"),
        (MASTER, "Master's, Doctorate or Professional degree"),
    ]

    NON_CONSUMER = 1
    ONCE_A_MONTH = 2
    TWO_FOUR_TIMES_A_MONTH = 3
    TWO_THREE_A_WEEK = 4
    MORE_THAN_FOUR_A_WEEK = 5

    HABIT_FREQUENCY = [
        (NON_CONSUMER, 'Do not consume'),
        (ONCE_A_MONTH, 'Less than 1 time a month'),
        (TWO_FOUR_TIMES_A_MONTH, '2-4 times a month'),
        (TWO_THREE_A_WEEK, '2-3 times a week'),
        (MORE_THAN_FOUR_A_WEEK, 'More than for 4 times a week'),
    ]

    KG = 'kg'
    LB = 'lb'

    WEIGHT_TYPE =[
        (KG, 'kg'),
        (LB, 'lb'),
    ]

    CM = 'cm'
    FT = 'ft'

    HEIGHT_TYPE = [
        (CM, 'cm'),
        (FT, 'ft'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="user")
    date_of_birth = models.DateField(
        validators=[validate_date_of_birth],
        null=True,
        blank=True
    )
    gender = models.IntegerField(choices=GENDER, null=True, blank=True)
    education = models.IntegerField(choices=EDUCATION, null=True, blank=True)
    weight = models.PositiveSmallIntegerField(blank=True, null=True)
    weight_type = models.CharField(max_length=2, choices=WEIGHT_TYPE, blank=True, null=True, default=KG)
    height = models.PositiveSmallIntegerField(blank=True, null=True)
    height_type = models.CharField(max_length=2, choices=HEIGHT_TYPE, blank=True, null=True, default=CM)
    is_smoker = models.IntegerField(choices=HABIT_FREQUENCY, default=NON_CONSUMER)
    is_drinker = models.IntegerField(choices=HABIT_FREQUENCY, default=NON_CONSUMER)
    avatar = models.ImageField(upload_to=path_and_rename, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, editable=False, null=True)
    updated_at = models.DateTimeField(auto_now=True, editable=False, null=True)

    def __str__(self):
        return self.user.email

    def save(self, *args, **kwargs):
        super().save()

        if self.avatar:
            img = Image.open(self.avatar.path)

            if img.height > 512 or img.height > 512:
                output_size = (512, 512)
                img.thumbnail(output_size)
                img.save(self.avatar.path)


# class GoogleToken(Token):
#     key = models.CharField(max_length=100, primary_key=True)
#     user = models.OneToOneField(
#         settings.AUTH_USER_MODEL, related_name='google_token',
#         on_delete=models.CASCADE
#     )
#
#
# class FacebookToken(Token):
#     key = models.CharField(max_length=100, primary_key=True)
#     user = models.OneToOneField(
#         settings.AUTH_USER_MODEL, related_name='facebook_token',
#         on_delete=models.CASCADE
#     )
