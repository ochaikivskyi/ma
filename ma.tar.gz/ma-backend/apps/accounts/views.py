import jwt
from django.conf import settings
from django.contrib.sites.shortcuts import get_current_site
from django.urls import reverse
from rest_auth.views import PasswordResetView, PasswordResetConfirmView
from rest_framework.generics import UpdateAPIView
# from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import IsAdminUser, AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST
from rest_framework.viewsets import ModelViewSet
from rest_framework.generics import GenericAPIView
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.pagination import LimitOffsetPagination

from apps.utils.utils import UserDataChecker
from ma.permissions import UserPermission

from apps.accounts.models import User, UserProfile
from apps.accounts.serializers import (
    UserSerializer,
    UserProfileSerializer,
    ChangePasswordSerializer,
    RegistrationSerializer,
    EmailVerificationSerializer,
)
from apps.accounts.utils import Util


class UserViewSet(ModelViewSet):
    """
    {
    "email": "str",
    "username": "str",
    "password": "str",
    "is_verified": "bool",
    }
    """
    serializer_class = UserSerializer
    queryset = User.objects.all()
    pagination_class = LimitOffsetPagination
    # parser_classes = (FormParser, MultiPartParser)

    def create(self, request, *args, **kwargs):
        serializer = UserSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        account_user = serializer.create(
            validated_data=serializer.data)

        user = User.objects.filter(id=account_user.id).first()
        user.set_password(request.data["password"])
        user.save()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get_queryset(self):
        user = self.request.user
        query_set = User.objects.filter(id=user.id)

        if user.is_staff:
            query_set = User.objects.all()

        return query_set

    def get_required_permissions(self):

        if self.action == "create":
            return [IsAdminUser]

        return [UserPermission]


class UserProfileViewSet(ModelViewSet):
    """
    {
    "date_of_birth": "str",
    "gender": "str",
    "education": "int",
    "weight": "int",
    "weight_type": "str",
    "height": "int",
    "height_type": "str",
    "is_smoker": "str",
    "is_drinker": "str",
    "avatar": "image_file",
    "user": "id(int)"
    }
    """
    permission_classes = [IsAuthenticated]
    serializer_class = UserProfileSerializer
    queryset = UserProfile.objects.all()
    pagination_class = LimitOffsetPagination
    # parser_classes = (FormParser, MultiPartParser)

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return UserProfile.objects.all()

        return UserProfile.objects.filter(user=user.id)


class ChangePasswordView(UpdateAPIView):
    """
    An endpoint for changing password.
    {
    "old_password": "str",
    "new_password_1": "str",
    "new_password_2": "str"
    }
    """
    serializer_class = ChangePasswordSerializer
    model = User
    permission_classes = [IsAuthenticated]

    def get_object(self, queryset=None):
        obj = self.request.user
        return obj

    def update(self, request, *args, **kwargs):
        user = self.get_object()
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            # Check old password
            if not user.check_password(serializer.data.get("old_password")):
                return Response(status=HTTP_400_BAD_REQUEST)
            elif serializer.data.get("new_password_1") == serializer.data.get("new_password_2"):
                user.set_password(serializer.data.get("new_password_1"))
                user.save()
                return Response(HTTP_200_OK)
            else:
                return Response("Passwords are not equal", status=HTTP_400_BAD_REQUEST)


class CustomPasswordResetView(PasswordResetView):

    def post(self, *args, **kwargs):
        return super(CustomPasswordResetView, self).post(*args, **kwargs)


class CustomPasswordResetConfirmView(PasswordResetConfirmView):

    def post(self, *args, **kwargs):
        return super(CustomPasswordResetConfirmView, self).post(*args, **kwargs)


class RegistrationGenericAPIView(GenericAPIView):
    serializer_class = RegistrationSerializer
    permission_classes = (AllowAny, )

    def post(self, request):
        user = request.data
        serializer = self.serializer_class(data=user)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        user_data = serializer.data

        user = User.objects.get(email=user_data["email"])

        token = RefreshToken.for_user(user).access_token

        current_site = get_current_site(request).domain
        # current_site = "127.0.0.1:8000"

        relative_link = reverse("email_verification")
        absolute_url = "http://" + current_site + relative_link + "?token=" + str(token)

        email_body = "Hi " + user.username + ".\nPlease follow the link below to verify your e-mail\n " + absolute_url

        data = {
            "email_body": email_body,
            "email_to": user.email,
            "email_subject": "Verify your email"
        }

        # Util.send_email(data)

        return Response(user_data, status=status.HTTP_201_CREATED)


class EmailVerificationAPIView(APIView):
    serializer_class = EmailVerificationSerializer

    def get(self, request):
        token = request.GET.get("token")

        try:
            payload = jwt.decode(token, settings.SECRET_KEY)
            user = User.objects.get(id=payload["user_id"])

            if not user.is_verified:
                user.is_verified = True
                user.save()

            return Response({"email": "Successfully verified"}, status=status.HTTP_200_OK)

        except jwt.ExpiredSignatureError:
            return Response({"error": "Activation link is expired!"}, status=status.HTTP_400_BAD_REQUEST)

        except jwt.exceptions.DecodeError:
            return Response({"error": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST)


class CompleteUserProfileAPIView(APIView):
    """
    {
        'user_sign_up': bool,
        'userprofile_info': bool,
        'slums': bool,
        'hads': bool,
        'lsns': bool,
        'sit_to_stand': bool,
        '5_minute_walk': bool,
        'read_passage_aloud': bool,
    }
    """
    permission_classes = (IsAuthenticated,)

    def get(self, *args, **kwargs):
        return Response(UserDataChecker(self.request.user).get_user_profile_data(), status=200)
