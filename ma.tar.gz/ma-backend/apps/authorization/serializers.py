from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.tokens import RefreshToken, TokenError

from apps.accounts.models import UserProfile

User = get_user_model()


class RefreshTokenSerializer(serializers.Serializer):
    refresh = serializers.CharField()

    default_error_messages = {
        "bad_token": "Token is invalid or expired"
    }

    def validate(self, attrs):
        self.token = attrs["refresh"]
        return attrs

    def save(self, **kwargs):
        try:
            RefreshToken(self.token).blacklist()
        except TokenError:
            self.fail("bad_token")


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):

    def validate(self, attrs):
        data = super(CustomTokenObtainPairSerializer, self).validate(attrs)
        checked_userprofile = UserProfile.objects.get_or_create(user=self.user)
        userprofile = checked_userprofile[0]
        data.update(
            {
                'user': {
                    'id': userprofile.user.id,
                    'email': userprofile.user.email,
                    'username': userprofile.user.username,
                    'created_at': userprofile.user.created_at,
                    'updated_at': userprofile.user.updated_at,
                    'userprofile': {
                        'id': userprofile.id,
                        'weight': userprofile.weight,
                        'weight_type': userprofile.weight_type,
                        'gender': userprofile.gender,
                        'education': userprofile.education,
                        'height': userprofile.height,
                        'height_type': userprofile.height_type,
                        'is_smoker': userprofile.is_smoker,
                        'is_drinker': userprofile.is_drinker,
                        'date_of_birth': userprofile.date_of_birth,
                        'avatar': str(userprofile.avatar),
                        'created_at': userprofile.created_at,
                        'updated_at': userprofile.updated_at
                    }
                }
            }
        )
        return data
