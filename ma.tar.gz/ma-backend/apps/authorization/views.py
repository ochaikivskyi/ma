from allauth.socialaccount.providers.facebook.views import FacebookOAuth2Adapter
from allauth.socialaccount.providers.google.views import GoogleOAuth2Adapter
from rest_auth.registration.views import SocialLoginView
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response

from apps.authorization.serializers import (
    RefreshTokenSerializer,
    CustomTokenObtainPairSerializer
)


class LogoutGenericAPIView(GenericAPIView):
    serializer_class = RefreshTokenSerializer
    permission_classes = (IsAuthenticated, )

    def post(self, request, *args):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response({"detail": "logged out"}, status=status.HTTP_204_NO_CONTENT)


class FacebookLogin(SocialLoginView):
    """
    {
    "access_token": "str",
    "code": "str"
    }
    """
    adapter_class = FacebookOAuth2Adapter


class GoogleLogin(SocialLoginView):
    """
    {
    "access_token": "str",
    "code": "str"
    }
    """
    adapter_class = GoogleOAuth2Adapter


class CustomTokenObtainPairView(TokenObtainPairView):
    # Replace the serializer with your custom
    serializer_class = CustomTokenObtainPairSerializer
