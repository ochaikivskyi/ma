from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.widgets.views import HomepageAPIView, DailyCheckinAPIView, DailyCheckinCitySearchAPIView

router = DefaultRouter()

urlpatterns = [
                  path(
                      "homepage/",
                      HomepageAPIView.as_view(),
                      name="homepage"
                  ),
                  path(
                      "daily-checkin/",
                      DailyCheckinAPIView.as_view(),
                      name="daily-checkin"
                  ),
                  path(
                      "daily-checkin-city-search/",
                      DailyCheckinCitySearchAPIView.as_view(),
                      name="daily-checkin-city-search"
                  )
              ] + router.urls
