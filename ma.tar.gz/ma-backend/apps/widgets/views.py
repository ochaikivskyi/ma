from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from geopy import Nominatim
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import User
from apps.utils.utils import AvailabilityChecker, DailyCheckinQuestions
from apps.widgets.models import DailyCheckin
from apps.widgets.serializers import DailyCheckinSerializer


class DailyCheckinAPIView(GenericAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = DailyCheckinSerializer
    queryset = DailyCheckin.objects.all()

    def get_queryset(self):
        user = self.request.user
        if user.is_staff:
            return DailyCheckin.objects.all()

        return DailyCheckin.objects.filter(user=user.id)

    def post(self, request, *args, **kwargs):
        user = User.objects.get(id=request.data.pop('user'))
        daily_checkin = DailyCheckin.objects.create(user=user, **request.data)
        return Response(
            data={
                'id': daily_checkin.id,
                'user': daily_checkin.user_id,
                'created_at': daily_checkin.created_at,
                'current_streak': AvailabilityChecker(user).check_current_streak()
            },
            status=201
        )

    category_response = openapi.Response(
        """{
    "physical": {
        "id": int,
        "question": "str",
        "answerType": "str",
        "options": []
    },
    "cognitive": {
        "id": int,
        "question": "str",
        "answerType": "str",
        "options": []
    },
    "emotional": {
        "id": int,
        "question": "str",
        "answerType": "str",
        "options": []
    }
    }"""
    )

    @swagger_auto_schema(
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='Daily Checkin Questions',
        operation_description='Retrieve questions for Daily Checkin',
    )
    def get(self, request, *args, **kwargs):
        user = User.objects.get(id=self.request.user.id)
        daily_checkin = DailyCheckinQuestions(user).get_daily_checkin_questions()
        return Response(
            daily_checkin,
            status=200
        )


class DailyCheckinCitySearchAPIView(APIView):
    permission_classes = [IsAuthenticated]
    search_word = openapi.Parameter(
        'search_word', in_=openapi.IN_QUERY, description='Search word for cities',
        type=openapi.TYPE_STRING
    )
    category_response = openapi.Response('{}')

    @swagger_auto_schema(
        manual_parameters=[search_word],
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='Found city',
        operation_description='Retrieve City for autocomplete',
    )
    def get(self, *args, **kwargs):
        try:
            search_word = self.request.query_params.get('search_word').capitalize()
            geo = Nominatim(user_agent='app').geocode(search_word).raw
            if geo:
                return Response(
                    {
                        'display_name': geo['display_name'],
                        'city': geo['display_name'].split(',')[0]
                    }, status=200
                )
            else:
                return Response(data={}, status=404)
        except Exception as e:
            return Response(data={}, status=404)


class HomepageAPIView(GenericAPIView):
    permission_classes = [IsAuthenticated]

    category_response = openapi.Response(
        """{
            "daily_checkin": "str",
            "current_streak": int,
            "available_in": {
                "slums": "str",
                "hads": "str",
                "lsns": "str",
                "read_passage_aloud": "str",
                "five_minute_walk": "str",
                "sit_to_stand": "str"
            }
        }"""
    )

    @swagger_auto_schema(
        manual_parameters=[],
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        operation_id='Homepage',
        operation_description='Retrieve data for Homepage',
    )
    def get(self, *args, **kwargs):
        return Response(
            data=AvailabilityChecker(self.request.user).check_homepage(),
            status=200
        )
