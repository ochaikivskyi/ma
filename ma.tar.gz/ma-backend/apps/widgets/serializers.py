from rest_framework import serializers

from apps.widgets.models import DailyCheckin


class DailyCheckinSerializer(serializers.ModelSerializer):

    class Meta:
        model = DailyCheckin
        fields = '__all__'
