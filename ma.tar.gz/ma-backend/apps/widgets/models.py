from django.db import models

from apps.accounts.models import User
from apps.utils.models import TimeStamp


class DailyCheckin(TimeStamp):

    user = models.ForeignKey(User, related_name="daily_checkin", on_delete=models.CASCADE)
    physical_question_id = models.PositiveSmallIntegerField(blank=True, null=True)
    physical_answer = models.TextField(blank=True, null=True)
    cognitive_question_id = models.PositiveSmallIntegerField(blank=True, null=True)
    cognitive_answer = models.TextField(blank=True, null=True)
    emotional_question_id = models.PositiveSmallIntegerField(blank=True, null=True)
    emotional_answer = models.TextField(blank=True, null=True)


# class DailyCheckinImage(TimeStamp):
#     name = models.CharField(max_length=50, blank=True, null=True)
#     picture = models.ImageField()

