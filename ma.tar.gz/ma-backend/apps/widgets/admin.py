from django.contrib import admin

from apps.widgets.models import DailyCheckin


admin.site.register(DailyCheckin)
