from django.db import models
from django.core.validators import FileExtensionValidator

from apps.accounts.models import User
from apps.utils.models import TimeStamp
from apps.voice_test.validators import path_and_rename


class ReadPassageAloud(TimeStamp):
    user = models.ForeignKey(
        User,
        related_name="read_passage_aloud",
        on_delete=models.CASCADE
    )
    rpa_voice_file = models.FileField(
        upload_to=path_and_rename,
        validators=[FileExtensionValidator(allowed_extensions=["mp3", "wav", "m4a"])],
        blank=True,
        null=True
    )
