from django.apps import AppConfig


class VoiceTestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.voice_test'
