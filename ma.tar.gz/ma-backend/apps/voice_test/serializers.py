from django.core.validators import FileExtensionValidator
from rest_framework import serializers

from apps.voice_test.models import ReadPassageAloud


class ReadPassageAloudSerializer(serializers.ModelSerializer):
    rpa_voice_file = serializers.FileField(
        validators=[FileExtensionValidator(allowed_extensions=["mp3", "wav", "m4a"])]
    )
    
    class Meta:
        model = ReadPassageAloud
        fields = (
            "id",
            "user",
            "rpa_voice_file"
        )
