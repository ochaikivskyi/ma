from rest_framework.parsers import FileUploadParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import ModelViewSet

from apps.voice_test.models import ReadPassageAloud
from apps. voice_test.serializers import ReadPassageAloudSerializer


class ReadPassageAloudViewSet(ModelViewSet):
    """
    {
        'user': "id(int)",
        'rpa_voice_file': "audio_file",
    }
    allowed_extensions = ["mp3", "wav", "m4a"]
    """
    permission_classes = (IsAuthenticated, )
    serializer_class = ReadPassageAloudSerializer
    queryset = ReadPassageAloud.objects.all()
    # parser_classes = (FileUploadParser, )

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return ReadPassageAloud.objects.all()

        return ReadPassageAloud.objects.filter(user=user.id)
