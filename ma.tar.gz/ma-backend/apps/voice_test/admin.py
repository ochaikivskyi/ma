from django.contrib import admin

from apps.voice_test.models import ReadPassageAloud


admin.site.register(ReadPassageAloud)
