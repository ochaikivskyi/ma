from rest_framework.routers import DefaultRouter

from apps.voice_test.views import ReadPassageAloudViewSet


router = DefaultRouter()
router.register("read-passage-aloud", ReadPassageAloudViewSet)

urlpatterns = [] + router.urls
