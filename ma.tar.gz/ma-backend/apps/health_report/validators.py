import os
from django.conf import settings
from datetime import datetime


def get_file_path():
    return os.path.join(settings.MEDIA_ROOT, "reports")


def validate_date_start(value):
    if value > datetime.now():
        raise ValueError("Incorrect date!")
    return value


def validate_date_end(value):
    if value > datetime.now():
        raise ValueError("Incorrect date!")
    return value
