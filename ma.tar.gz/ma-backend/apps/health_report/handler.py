import pytz
from dateutil import parser

from apps.voice_test.models import ReadPassageAloud
from apps.physical_test.models import (
    SLUMS,
    SitToStand,
    FiveMinuteWalk,
    HADS,
    LSNS
)


class HealthReportCardHandler:
    def __init__(self, user):
        self.user = user

    def get_sit_to_stand_results(self, date_start, date_end):
        date_start = parser.parse(date_start).replace(tzinfo=pytz.UTC)
        date_end = parser.parse(date_end).replace(tzinfo=pytz.UTC)
        results = self.__get_test_results(SitToStand, date_start, date_end)
        sit_to_stand_results = []
        for result in results:
            sit_to_stand_results.append(
                {
                    "user": result.user.id,
                    "sits_quantity": result.sits_quantity,
                    "created_at": result.created_at,
                    "updated_at": result.updated_at
                 }
            )
        return sit_to_stand_results

    def get_slums_results(self, date_start, date_end):
        date_start = parser.parse(date_start).replace(tzinfo=pytz.UTC)
        date_end = parser.parse(date_end).replace(tzinfo=pytz.UTC)
        results = self.__get_test_results(SLUMS, date_start, date_end)
        slums_results = []
        for result in results:
            slums_results.append(
                {
                    "user": result.user.id,
                    "total_result": result.total_result,
                    "created_at": result.created_at,
                    "updated_at": result.updated_at
                }
            )
        return slums_results

    def get_five_minute_walk_results(self, date_start, date_end):
        date_start = parser.parse(date_start).replace(tzinfo=pytz.UTC)
        date_end = parser.parse(date_end).replace(tzinfo=pytz.UTC)
        results = self.__get_test_results(FiveMinuteWalk, date_start, date_end)
        five_minute_walk_results = []
        for result in results:
            five_minute_walk_results.append(
                {
                    "user": result.user.id,
                    "distance_type": result.distance_type,
                    "distance": result.distance,
                    "created_at": result.created_at,
                    "updated_at": result.updated_at
                }
            )
        return five_minute_walk_results

    def get_lsns_results(self, date_start, date_end):
        date_start = parser.parse(date_start).replace(tzinfo=pytz.UTC)
        date_end = parser.parse(date_end).replace(tzinfo=pytz.UTC)
        results = self.__get_test_results(LSNS, date_start, date_end)
        lsns_results = []
        for result in results:
            lsns_results.append(
                {
                    "user": result.user.id,
                    "relatives_total_score": result.relatives_total_score,
                    "friends_total_score": result.friends_total_score,
                    "total_score": result.total_score,
                    "created_at": result.created_at,
                    "updated_at": result.updated_at
                }
            )
        return lsns_results

    def get_hads_results(self, date_start, date_end):
        date_start = parser.parse(date_start).replace(tzinfo=pytz.UTC)
        date_end = parser.parse(date_end).replace(tzinfo=pytz.UTC)
        results = self.__get_test_results(HADS, date_start, date_end)
        hads_results = []
        for result in results:
            hads_results.append(
                {
                    "user": result.user.id,
                    "total_score": result.total_score,
                    "created_at": result.created_at,
                    "updated_at": result.updated_at
                }
            )
        return hads_results

    def __get_test_results(self, test, date_start, date_end):
        return test.objects.filter(
            user=self.user,
            created_at__lte=date_end
        ).exclude(
            created_at__lte=date_start
        ).order_by(
            "-created_at"
        )
