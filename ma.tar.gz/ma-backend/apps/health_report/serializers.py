from rest_framework import serializers

from apps.health_report.models import HealthReportCard
from apps.health_report.validators import get_file_path


class HealthReportCardSerializer(serializers.ModelSerializer):
    report_file = serializers.FilePathField(
        path=get_file_path(),
        allow_files=True,
        allow_folders=True,
    )

    class Meta:
        model = HealthReportCard
        fields = (
            # "report",
            "created_at",
            "updated_at",
            "date_start",
            "date_end",
            "date_generated",
            "report_file"
        )
