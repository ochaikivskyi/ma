from rest_framework.urls import path
from rest_framework.routers import DefaultRouter

from apps.health_report.views import HealthReportCardGenericAPIView

router = DefaultRouter()

urlpatterns = [
                  path(
                      "",
                      HealthReportCardGenericAPIView.as_view(),
                      name="health-report-card"
                  ),
              ] + router.urls
