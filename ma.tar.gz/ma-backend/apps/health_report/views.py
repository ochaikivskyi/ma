import io

from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter

from apps.accounts.models import User
from apps.health_report.handler import HealthReportCardHandler
from apps.health_report.models import HealthReportCard
from apps.health_report.serializers import HealthReportCardSerializer


class HealthReportCardGenericAPIView(GenericAPIView):
    permission_classes = (IsAuthenticated, )
    serializer_class = HealthReportCardSerializer
    queryset = HealthReportCard.objects.all()

    def get_queryset(self):
        user = self.request.user

        if user.is_staff:
            return HealthReportCard.objects.all()

        return HealthReportCard.objects.filter(user=user.id)

    def post(self, request, *args, **kwargs):
        user = User.objects.get(id=self.request.user.id)
        health_report = HealthReportCard.objects.create(
            user=user,
            **request.data
        )

        sit_to_stand_report = HealthReportCardHandler(
            user
        ).get_sit_to_stand_results(
            date_start=health_report.date_start,
            date_end=health_report.date_end
        )

        slums_report = HealthReportCardHandler(
            user
        ).get_slums_results(
            date_start=health_report.date_start,
            date_end=health_report.date_end
        )

        five_minute_walk_report = HealthReportCardHandler(
            user
        ).get_five_minute_walk_results(
            date_start=health_report.date_start,
            date_end=health_report.date_end
        )

        lsns_report = HealthReportCardHandler(
            user
        ).get_lsns_results(
            date_start=health_report.date_start,
            date_end=health_report.date_end
        )

        hads_report = HealthReportCardHandler(
            user
        ).get_hads_results(
            date_start=health_report.date_start,
            date_end=health_report.date_end
        )

        report_file = self.render_pdf_report(
            sit_to_stand_report=sit_to_stand_report,
            slums_report=slums_report,
            five_minute_walk_report=five_minute_walk_report,
            lsns_report=lsns_report,
            hads_report=hads_report
        )

        return Response(
            data={
                "id": health_report.id,
                "user": health_report.user_id,
                "created_at": health_report.created_at,
                "sit_to_stand_report": sit_to_stand_report,
                "slums_report": slums_report,
                "five_minute_walk_report": five_minute_walk_report,
                "lsns_report": lsns_report,
                "hads_report": hads_report,
                "report_file": report_file
            },
            status=201
        )

    def render_pdf_report(self, **kwargs):
        pdf_report = "media/reports/report.pdf"

        buffer = io.BytesIO()
        canv = canvas.Canvas(pdf_report, pagesize=letter, bottomup=0)

        text = canv.beginText()
        text.setTextOrigin(inch, inch)
        text.setFont("Helvetica", 14)

        lines = [
            [sits.get("sits_quantity") for sits in kwargs.get("sit_to_stand_report")],
            [distance.get("distance") for distance in kwargs.get("five_minute_walk_report")],
            kwargs.get("slums_report"),
            kwargs.get("lsns_report"),
            kwargs.get("hads_report"),
        ]

        for line in lines:
            text.textLine(str(line))

        canv.drawText(text)
        canv.showPage()
        canv.save()

        buffer.seek(0)

        return pdf_report
