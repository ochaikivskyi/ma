from django.contrib import admin

from apps.health_report.models import HealthReportCard


admin.site.register(HealthReportCard)
