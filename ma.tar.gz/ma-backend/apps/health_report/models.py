from django.db import models

from apps.accounts.models import User
from apps.utils.models import TimeStamp
from apps.health_report.validators import (
    get_file_path,
    validate_date_start,
    validate_date_end
)


class HealthReportCard(TimeStamp):
    user = models.ForeignKey(
        User,
        related_name="health_report_card",
        on_delete=models.CASCADE
    )
    date_start = models.DateTimeField(
        validators=[validate_date_start],
        blank=True,
        null=True
    )
    date_end = models.DateTimeField(
        validators=[validate_date_end],
        blank=True,
        null=True
    )
    date_generated = models.DateTimeField(
        validators=[validate_date_end],
        blank=True,
        null=True
    )
    is_full_report = models.BooleanField(default=True)
    report_file = models.FilePathField(
        path=get_file_path,
        allow_files=True,
        allow_folders=True,
        null=True,
        blank=True
    )
