from django.contrib import admin

# Register your models here.
from apps.notifications.models import NotificationSetting, Notification

admin.site.register(NotificationSetting)
admin.site.register(Notification)
