from datetime import datetime, timedelta

from celery import shared_task

from django.db.models import Max
from django.utils import timezone
# from fcm_django.models import FCMDevice
import firebase_admin
from firebase_admin import credentials
from firebase_admin.messaging import Message

from apps.accounts.models import User
from apps.notifications.models import Notification
from apps.physical_test.models import SLUMS, HADS, LSNS, FiveMinuteWalk, SitToStand
from apps.voice_test.models import ReadPassageAloud
from apps.widgets.models import DailyCheckin


cred = credentials.Certificate('modern-3cc56-firebase-adminsdk-7mksc-0693378cbe.json')
daily_app = firebase_admin.initialize_app(cred)


def get_test_type(test) -> (str, str):
    if test == SLUMS:
        return 'slums', 'SLUMS'
    elif test == HADS:
        return 'hads', 'HADS'
    elif test == LSNS:
        return 'lsns', 'LSNS'
    elif test == ReadPassageAloud:
        return 'read_aloud', 'Read Passage Aloud'
    elif test == FiveMinuteWalk:
        return 'walk', 'Five Minute Walk'
    elif test == SitToStand:
        return 'sit_stand', 'Sit To Stand'


@shared_task
def check_cognitive_notification() -> None:
    from fcm_django.models import FCMDevice

    list_of_tests = [SLUMS, HADS, LSNS, ReadPassageAloud]
    for current_test in list_of_tests:
        tests = current_test.objects.all()
        user_max = User.objects.aggregate(Max('id'))

        for user_id in range(user_max.get('id__max')):
            test = tests.filter(user=user_id).last()
            if test:
                time_diff = datetime.now(tz=timezone.utc) - test.created_at
                if FCMDevice.objects.filter(user_id=user_id):
                    device: FCMDevice = FCMDevice.objects.get(user_id=user_id)
                    test = get_test_type(current_test)
                    if time_diff.days >= 90:
                        notification: Notification = Notification.objects.create(
                            user=User.objects.get(id=user_id),
                            notification_type=test[0],
                            notification_message="Complete "+test[1]+" Test.",
                            action_type='info'
                        )
                        data = {
                            "user": str(user_id),
                            "type": notification.notification_type,
                            "title": notification.notification_message,
                            "seen": str(notification.is_seen),
                            'action': notification.action_type,
                            "date": notification.created_at.isoformat()
                        }
                        device.send_message(
                            Message(
                                data=data,
                            )
                        )
                    elif time_diff.days == 88:
                        notification = Notification.objects.create(
                            user=User.objects.get(id=user_id),
                            notification_type=test[0],
                            notification_message=test[1]+" Test will be available in 2 days",
                            action_type="info"
                        )
                        data = {
                            "user": str(user_id),
                            "type": notification.notification_type,
                            "title": notification.notification_message,
                            "seen": str(notification.is_seen),
                            "action": notification.action_type,
                            "date": notification.created_at.isoformat()
                        }
                        device.send_message(
                            Message(
                                data=data,
                            )
                        )


@shared_task
def check_physical_notification() -> None:
    from fcm_django.models import FCMDevice

    list_of_test = [FiveMinuteWalk, SitToStand]
    for current_test in list_of_test:
        tests = current_test.objects.all()
        user_max = User.objects.aggregate(Max('id'))

        for user_id in range(user_max.get('id__max')):
            test = tests.filter(user=user_id).last()
            if test:
                time_diff: timedelta = datetime.now(tz=timezone.utc) - test.created_at
                if FCMDevice.objects.filter(user_id=user_id):
                    device: FCMDevice = FCMDevice.objects.get(user_id=user_id)
                    test = get_test_type(current_test)
                    if time_diff.days >= 90:
                        notification = Notification.objects.create(
                            user=User.objects.get(id=user_id),
                            notification_type=test[0],
                            notification_message="Complete "+test[1]+" Test.",
                            action_type="info"
                        )
                        data = {
                            "user": str(user_id),
                            "type": notification.notification_type,
                            "title": notification.notification_message,
                            "seen": str(notification.is_seen),
                            "action": notification.action_type,
                            "date": notification.created_at.isoformat()
                        }
                        device.send_message(
                            Message(
                                data=data,
                            )
                        )
                    elif time_diff.days == 88:
                        notification: Notification = Notification.objects.create(
                            user=User.objects.get(id=user_id),
                            notification_type=test[0],
                            notification_message=test[1] + " Test will be available in 2 days",
                            action_type="info"
                        )
                        data = {
                            "user": str(user_id),
                            "type": notification.notification_type,
                            "title": notification.notification_message,
                            "seen": str(notification.is_seen),
                            "action": notification.action_type,
                            "date": notification.created_at.isoformat()
                        }
                        device.send_message(
                            Message(
                                data=data,
                            )
                        )


@shared_task
def check_daily_checkin_notification() -> None:
    from fcm_django.models import FCMDevice

    daily_checkins = DailyCheckin.objects.all()
    user_max = User.objects.aggregate(Max('id'))

    for user_id in range(user_max.get('id__max')):
        test: DailyCheckin = daily_checkins.filter(user=user_id).last()
        if test:
            time_diff: timedelta = datetime.now(tz=timezone.utc) - test.created_at
            if FCMDevice.objects.filter(user=user_id):
                device: FCMDevice = FCMDevice.objects.get(user=user_id)
                if time_diff.days >= 1:
                    notification: Notification = Notification.objects.create(
                        user=User.objects.get(id=user_id),
                        notification_type="check_in",
                        notification_message="Take a moment to check-in with your well-being today.",
                        action_type="info"
                    )
                    data = {
                        "user": str(user_id),
                        "type": notification.notification_type,
                        "title": notification.notification_message,
                        "seen": str(notification.is_seen),
                        "action": notification.action_type,
                        "date": notification.created_at.isoformat()
                    }
                    device.send_message(
                        Message(
                            data=data,
                        )
                    )
