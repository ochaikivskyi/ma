from django.db import models

from apps.accounts.models import User
from apps.utils.models import TimeStamp


class NotificationSetting(models.Model):
    user = models.OneToOneField(User, related_name="notification_settings", on_delete=models.CASCADE)
    daily_checkin_reminder = models.BooleanField(blank=True, null=True, default=True)
    assessments_reminder = models.BooleanField(blank=True, null=True, default=True)


class Notification(TimeStamp):

    user = models.ForeignKey(User, related_name='notification', on_delete=models.CASCADE)
    notification_type = models.CharField(max_length=100, blank=True, null=True)
    notification_message = models.CharField(max_length=150, blank=True, null=True)
    is_seen = models.BooleanField(blank=True, null=True, default=False)
    action_type = models.CharField(max_length=50, blank=True, null=True)
