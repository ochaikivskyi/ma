from drf_yasg.utils import swagger_auto_schema
from fcm_django.models import FCMDevice
from rest_framework.generics import GenericAPIView
from rest_framework.mixins import UpdateModelMixin
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response

from apps.notifications.models import NotificationSetting, Notification
from apps.notifications.serializers import NotificationSettingSerializer, RegisterDeviceSerializer, \
    NotificationSerializer


class NotificationSettingAPIView(GenericAPIView, UpdateModelMixin):
    permission_classes = (IsAuthenticated,)
    serializer_class = NotificationSettingSerializer
    queryset = NotificationSetting.objects.all()

    def get(self, request, *args, **kwargs):
        notification_settings: NotificationSetting = NotificationSetting.objects.get(user=self.request.user)
        return Response(
            data={
                "id": notification_settings.id,
                "daily_checkin_reminder": notification_settings.daily_checkin_reminder,
                "assessments_reminder": notification_settings.assessments_reminder,
                "user": notification_settings.user_id
            },
            status=200
        )

    def patch(self, request, *args, **kwargs):
        NotificationSetting.objects.filter(
            user=self.request.user
        ).update(
            **request.data
        )
        notification_settings: NotificationSetting = NotificationSetting.objects.get(
            user=self.request.user
        )
        return Response(
            data={
                "id": notification_settings.id,
                "daily_checkin_reminder": notification_settings.daily_checkin_reminder,
                "assessments_reminder": notification_settings.assessments_reminder,
                "user": notification_settings.user.id
            },
            status=200
        )


class RegisterDeviceView(GenericAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = RegisterDeviceSerializer
    queryset = FCMDevice.objects.all()

    @swagger_auto_schema(
        security=[],
        operation_id='Register Device',
        operation_description='Register Device which is gonna receive notifications'
    )
    def post(self, request, *args, **kwargs):
        if FCMDevice.objects.filter(user=self.request.user):
            FCMDevice.objects.get(
                user=self.request.user
            ).delete()
            device = FCMDevice.objects.create(user=self.request.user, **request.data)
        else:
            device = FCMDevice.objects.create(user=self.request.user, **request.data)
            NotificationSetting.objects.create(user=self.request.user)
        request.data['id'] = device.id
        return Response(
            data=request.data,
            status=201
        )


class NotificationsAPIView(APIView, UpdateModelMixin):
    permission_classes = (IsAuthenticated,)
    queryset = Notification.objects.all()
    category_response = '''
    [
    {
        'id': int,
        'notification_type': str,
        'notification_message': str,
        'is_seen': bool,
        'action_type': str,
        'created_at': datetime
    }
    ]
    '''

    @swagger_auto_schema(
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='List of Notifications',
        operation_description='Retrieve List of Notifications',
    )
    def get(self, *args, **kwargs):
        notifications = Notification.objects.filter(user=self.request.user)
        return Response(
            data=[
                {
                    'id': notification.id,
                    'notification_type': notification.notification_type,
                    'notification_message': notification.notification_message,
                    'is_seen': notification.is_seen,
                    'action_type': notification.action_type,
                    'created_at': notification.created_at
                } for notification in notifications
            ],
            status=200
        )

    @swagger_auto_schema(
        responses={
            '200': category_response,
            '404': 'Not found'
        },
        security=[],
        operation_id='Change Notification to seen status',
        operation_description='Change notifications to seen'
    )
    def patch(self, *args, **kwargs):
        Notification.objects.filter(
            user=self.request.user
        ).update(
            is_seen=True
        )
        notifications = Notification.objects.filter(
            user=self.request.user
        )
        return Response(
            data=[
                {
                    'id': notification.id,
                    'notification_type': notification.notification_type,
                    'notification_message': notification.notification_message,
                    'is_seen': notification.is_seen,
                    'action_type': notification.action_type,
                    'created_at': notification.created_at
                } for notification in notifications
            ],
            status=200
        )
