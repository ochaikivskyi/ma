from fcm_django.models import FCMDevice
from rest_framework import serializers

from apps.accounts.models import User
from apps.notifications.models import NotificationSetting, Notification


class NotificationSettingSerializer(serializers.ModelSerializer):

    class Meta:
        model = NotificationSetting
        fields = '__all__'


class NotificationSerializer(serializers.ModelSerializer):

    class Meta:
        model = Notification
        fields = ('user', 'is_seen')


class RegisterDeviceSerializer(serializers.ModelSerializer):

    class Meta:
        model = FCMDevice
        fields = ('device_id', 'registration_id', 'type', 'active')
