from django.urls import path

from apps.notifications.views import RegisterDeviceView, NotificationsAPIView, \
    NotificationSettingAPIView


urlpatterns = [
                  path(
                      "register-device/",
                      RegisterDeviceView.as_view(),
                      name="register-device"
                  ),
                  path(
                      "list-notifications/",
                      NotificationsAPIView.as_view(),
                      name="list-notifications"
                  ),
                  path(
                      "notification-settings/",
                      NotificationSettingAPIView.as_view(),
                      name="list-notifications"
                  ),
              ]
